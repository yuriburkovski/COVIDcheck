package com.example.covidcheck;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    private Button checkButton;
    private Button exitButton;
    private OkHttpClient client;
    private TextView result;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addListenerOnButton();
    }

    public void addListenerOnButton() {
        checkButton = findViewById(R.id.check);
        exitButton = findViewById(R.id.exit2);
        checkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getJson();

            }
        });
        exitButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AlertDialog.Builder a2_builder = new AlertDialog.Builder(MainActivity.this);
                        a2_builder.setMessage("Chcesz wyjść z aplikacji?")
                                .setCancelable(false)
                                .setPositiveButton("Tak", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        finish();
                                    }
                                })
                                .setNegativeButton("Nie", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                    }
                                });
                        AlertDialog alert2 = a2_builder.create();
                        alert2.setTitle("Zamykam");
                        alert2.show();
                    }
                }
        );
    }

    private void getJson() {
        client = new OkHttpClient();
        final DataModel data = new DataModel();
        result = findViewById(R.id.result);
        Request request = new Request.Builder()
                .url("https://corona.lmao.ninja/v2/all")
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        result.setText("Failure!");
                    }
                });
            }

            @Override
            public void onResponse(Call call, final Response response) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {

                            String jsonStr = response.body().string();
                            JSONObject jsObj = new JSONObject(jsonStr);

                            data.cases = jsObj.getInt("cases");
                            data.todayCases = jsObj.getInt("todayCases");
                            data.deaths = jsObj.getInt("deaths");
                            data.todayDeaths = jsObj.getInt("todayDeaths");
                            data.active = jsObj.getInt("active");
                            data.critical = jsObj.getInt("critical");
                            data.recovered = jsObj.getInt("recovered");
                            result.setText("Cases:   " + data.cases +
                                    "\nToday cases:   " + data.todayCases +
                                    "\nDeaths:   " + data.deaths +
                                    "\nToday deaths:   " + data.todayDeaths +
                                    "\nActive:   " + data.active +
                                    "\nCritical:   " + data.critical +
                                    "\nRecovered:   " + data.recovered);

                        } catch (IOException | JSONException e) {
                            result.setText("Error");
                        }
                    }
                });
            }
        });
    }
}

