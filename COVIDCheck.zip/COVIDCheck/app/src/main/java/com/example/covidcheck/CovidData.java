package com.example.covidcheck;

class CovidData {
    public int cases;
    public int todayCases;
    public int deaths;
    public int todayDeaths;
    public int recovered;
    public int active;
    public int critical;

    public CovidData(int cases, int todayCases, int deaths, int todayDeaths, int recovered, int active, int critical) {
        this.cases = cases;
        this.todayCases = todayCases;
        this.deaths = deaths;
        this.todayDeaths = todayDeaths;
        this.recovered = recovered;
        this.active = active;
        this.critical = critical;
    }

    public CovidData() {

    }

    public int getCases() {
        return cases;
    }

    public int getTodayCases() {
        return todayCases;
    }

    public int getDeaths() {
        return deaths;
    }

    public int getTodayDeaths() {
        return todayDeaths;
    }

    public int getRecovered() {
        return recovered;
    }

    public int getActive() {
        return active;
    }

    public int getCritical() {
        return critical;
    }

    public void setCases(int cases) {
        this.cases = cases;
    }

    public void setTodayCases(int todayCases) {
        this.todayCases = todayCases;
    }

    public void setDeaths(int deaths) {
        this.deaths = deaths;
    }

    public void setTodayDeaths(int todayDeaths) {
        this.todayDeaths = todayDeaths;
    }

    public void setRecovered(int recovered) {
        this.recovered = recovered;
    }

    public void setActive(int active) {
        this.active = active;
    }

    public void setCritical(int critical) {
        this.critical = critical;
    }

    @Override
    public String toString() {
        return "Cases=" + cases +
                ", \nTodayCases=" + todayCases +
                ", \nDeaths=" + deaths +
                ", \nTodayDeaths=" + todayDeaths +
                ", \nRecovered=" + recovered +
                ", \nActive=" + active +
                ", \nCritical=" + critical;
    }
}
